
// =====================================
   GOD'S HOPE ORPHANAGE WEBSITE 
// =====================================

// Welcome Message
window.addEventListener("load", function () {
    console.log("God's Hope Orphanage Website Loaded Successfully");
});

// =====================================
// DONATION 
// =====================================

function donateMessage() {
    alert("Thank you for your interest in supporting God's Hope Orphanage. Your contribution helps change lives.");
}

// =====================================
// CURRENT YEAR IN FOOTER
// =====================================

document.addEventListener("DOMContentLoaded", function () {

    const yearElement = document.getElementById("year");

    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }

});

// =====================================
// GALLERY 
// =====================================

document.addEventListener("DOMContentLoaded", function () {

    const galleryImages = document.querySelectorAll(".gallery img");

    galleryImages.forEach(function (image) {

        image.addEventListener("click", function () {

            const lightbox = document.createElement("div");

            lightbox.id = "lightbox";

            lightbox.style.position = "fixed";
            lightbox.style.top = "0";
            lightbox.style.left = "0";
            lightbox.style.width = "100%";
            lightbox.style.height = "100%";
            lightbox.style.backgroundColor = "rgba(0,0,0,0.9)";
            lightbox.style.display = "flex";
            lightbox.style.justifyContent = "center";
            lightbox.style.alignItems = "center";
            lightbox.style.cursor = "pointer";
            lightbox.style.zIndex = "9999";

            const img = document.createElement("img");

            img.src = image.src;
            img.style.maxWidth = "90%";
            img.style.maxHeight = "90%";
            img.style.borderRadius = "10px";

            lightbox.appendChild(img);

            document.body.appendChild(lightbox);

            lightbox.addEventListener("click", function () {
                lightbox.remove();
            });

        });

    });

});

// =====================================
// SCROLL TO TOP BUTTON
// =====================================

document.addEventListener("DOMContentLoaded", function () {

    const button = document.createElement("button");

    button.innerHTML = "↑";

    button.style.position = "fixed";
    button.style.bottom = "20px";
    button.style.right = "20px";
    button.style.padding = "10px 15px";
    button.style.fontSize = "20px";
    button.style.display = "none";
    button.style.border = "none";
    button.style.borderRadius = "50%";
    button.style.cursor = "pointer";
    button.style.zIndex = "999";

    document.body.appendChild(button);

    window.addEventListener("scroll", function () {

        if (window.scrollY > 300) {
            button.style.display = "block";
        } else {
            button.style.display = "none";
        }

    });

    button.addEventListener("click", function () {

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    });

});

// =====================================
// CONTACT PAGE 
// =====================================

function validateForm() {

    const name = document.getElementById("name");
    const email = document.getElementById("email");

    if (!name || !email) {
        return true;
    }

    if (name.value.trim() === "") {

        alert("Please enter your name.");
        name.focus();
        return false;

    }

    if (email.value.trim() === "") {

        alert("Please enter your email address.");
        email.focus();
        return false;

    }

    alert("Form submitted successfully!");
    return true;

}